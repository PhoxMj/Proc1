CREATE VIEW emp_v2 AS
  SELECT
    `myemployees`.`departments`.`department_id`   AS `department_id`,
    `myemployees`.`departments`.`department_name` AS `department_name`,
    `myemployees`.`departments`.`manager_id`      AS `manager_id`,
    `myemployees`.`departments`.`location_id`     AS `location_id`
  FROM `myemployees`.`departments`
  WHERE `myemployees`.`departments`.`department_id` IN (SELECT `myemployees`.`employees`.`department_id`
                                                        FROM `myemployees`.`employees`
                                                        GROUP BY `myemployees`.`employees`.`department_id`
                                                        HAVING (max(`myemployees`.`employees`.`salary`) > 12000));

