CREATE TRIGGER tr_emp
  BEFORE UPDATE
  ON employees
  FOR EACH ROW
  BEGIN
        insert into t_employees
        values(old.employee_id,old.first_name,old.last_name,
               old.email,old.phone_number,old.job_id,old.salary,
               old.commission_pct,old.manager_id,old.department_id,
               old.hiredate);
    END;

