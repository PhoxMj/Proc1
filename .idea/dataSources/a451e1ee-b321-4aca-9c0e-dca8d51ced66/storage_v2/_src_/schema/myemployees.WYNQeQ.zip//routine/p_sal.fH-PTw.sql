CREATE PROCEDURE p_sal(IN deptId INT(4))
  BEGIN
	declare sal double(10,2);
	declare empId int(6);
	declare done int default 0;
	declare cur cursor for select employee_id,salary from employees where department_id =deptId;
	declare continue HANDLER for not found set done = 1;
	-- DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
	open cur;
	
	-- 使用while...do循环体
	/*fetch cur into empId,sal;
	while done = 1 do
		-- set total = total + c;
		select now(); 
		update employees
		set salary = sal + 200
		where employee_id=empId;
		FETCH cur INTO empId,sal;
	end while;*/
	-- -- 使用loop循环体
	/*read_loop:loop
	FETCH cur INTO empId,sal;
	
	if done=0 then
		leave read_loop; -- 跳出游标循环
	end if;
	-- 测试看循环体是否执行
	-- select now(); 
	
	UPDATE employees
	SET salary = sal + 200
	WHERE employee_id=empId;
	
	end loop;*/
	
	-- 使用repeat循环体
        repeat
	FETCH cur INTO empId,sal;
	if not done then
		UPDATE employees
		SET salary = sal + 200
		WHERE employee_id=empId;
	end if;
	until done end repeat;	
	
	close cur;
	-- select total;
END;

