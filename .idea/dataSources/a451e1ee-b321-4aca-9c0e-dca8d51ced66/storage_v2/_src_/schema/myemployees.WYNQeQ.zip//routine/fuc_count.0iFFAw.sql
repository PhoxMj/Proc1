CREATE FUNCTION fuc_count(job_id VARCHAR(10))
  RETURNS INT
  begin
   declare count int default 0;
   select count(*) into count
   from employees e
   where e.job_id = job_id;
   return count;
end;

