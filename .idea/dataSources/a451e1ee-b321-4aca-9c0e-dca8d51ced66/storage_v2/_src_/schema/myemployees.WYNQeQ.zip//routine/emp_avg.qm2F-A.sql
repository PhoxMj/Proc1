CREATE FUNCTION emp_avg(deptName VARCHAR(20))
  RETURNS DOUBLE
  BEGIN
     SET @sal=0;
     
     SELECT AVG(salary) INTO @sal
     FROM employees e
     JOIN departments d ON e.department_id = d.department_id
     WHERE d.department_name = deptName;
     
     RETURN @sal;
END;

