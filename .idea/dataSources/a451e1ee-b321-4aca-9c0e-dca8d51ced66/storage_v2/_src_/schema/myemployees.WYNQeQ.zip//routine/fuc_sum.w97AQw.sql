CREATE FUNCTION fuc_sum(a INT, b INT)
  RETURNS INT
  BEGIN
  -- 声明局部变量  
  /*
  DECLARE SUM INT DEFAULT 0;
  SET SUM = a + b;
  RETURN SUM;
  */
  -- 声明用户变量
  SET @SUM:=0;
  SET @SUM = a + b;
  RETURN @SUM;  
END;

