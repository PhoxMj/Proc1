CREATE FUNCTION fuc_manager(Lname VARCHAR(20))
  RETURNS VARCHAR(20)
  begin
  declare manager varchar(20);
  
  select m.last_name into manager 
  from employees e inner join employees m on e.manager_id = m.employee_id
  where e.last_name = Lname;
  
  return manager;
end;

