CREATE FUNCTION emp_c()
  RETURNS INT
  begin
     declare c int default 0;     
     select count(*) into c
     from employees;
     
     return c;
end;

